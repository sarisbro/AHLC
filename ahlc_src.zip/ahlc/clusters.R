# to run this script in batch mode, type:
# R CMD BATCH cluster.R
#
# setwd("~/Documents/data/Colomban/latest/34taxa/new.roots/dates/baseml/clock5.6/paml315")
library(hopach)							# for Hierarchical Ordered Partitioning and Collapsing Hybrid 
myrates    <- read.table("rates.in")
nbclusters <- 3
nbrates    <- 68
nbgenes    <- 3
nbCalibPts <- 7
maxNbClust <- ((nbrates + 2)/2 - 2 + nbCalibPts)/nbgenes
restable3  <- matrix(nrow = nbrates * nbgenes, ncol = 5)

pdf(width=10, height=10, onefile=FALSE)
for(i in 1:nbgenes){
	# HOPACH: van der Laan, M.J. and Pollard (2003)
	mydist <- distancematrix( myrates[,c(3)][myrates[,c(1)] == i], d="euclid" )
	curK = 10
	kfound = maxNbClust + 1
	while(kfound > maxNbClust){
		curK = curK - 1
		clustresult <- hopach( myrates[,c(3)][myrates[,c(1)] == i], dmat=mydist, clusters="best",kmax=curK,khigh=curK )
		kfound = clustresult$clustering$k
	}
	dplot(mydist, clustresult, labels=myrates[,c(2)][myrates[,c(1)] == i], main = i)
	
	for(j in 1:nbrates){
		restable3[nbrates*(i-1)+j, 1] <- myrates[nbrates*(i-1)+j,1]         # gene ID
		restable3[nbrates*(i-1)+j, 2] <- myrates[nbrates*(i-1)+j,2]         # branch ID
		restable3[nbrates*(i-1)+j, 3] <- myrates[nbrates*(i-1)+j,3]         # approx rate estimate
		restable3[nbrates*(i-1)+j, 4] <- clustresult$clustering$labels[j]   # cluster ID
		restable3[nbrates*(i-1)+j, 5] <- clustresult$clustering$k           # number of clusters
	}
}
dev.off()

# write out results to files
write.table(restable3, file = "rates_hopach.out")

rm(nbclusters,restable3,mydist,clustresult,maxNbClust,nbCalibPts,curK,kfound)
q(save = "no")
